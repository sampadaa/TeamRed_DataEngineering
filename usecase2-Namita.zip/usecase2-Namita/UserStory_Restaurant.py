import pymongo
import csv,json

#Connecting to database
conn = "mongodb+srv://namita:mongodb@cluster0.tn7xj.mongodb.net/Hotel_database?retryWrites=true&w=majority"
client = pymongo.MongoClient(conn)
db = client["Hotel_database"]

staffcollection = db.Staff_collection
restaurantcollection = db.Restaurant_collection

# #Converting csv to json
# csvFilePath = 'D:/LECTURES/RESTAURANT_DATA.csv'
# jsonFilePath = 'D:/LECTURES/RESTAURANT.json'
# data = {}
# with open(csvFilePath) as csvFile:
#     csvReader = csv.DictReader(csvFile)
#     for rows in csvReader:
#         id = rows['id']
#         data[id] = rows
# with open(jsonFilePath,'w') as  jsonFile:
#     jsonFile.write(json.dumps(data, indent=4))

# # Inserting data to restaurant data store
with open(r'D:/LECTURES/RESTAURANT.json', 'r') as data_file:
    data_json = json.load(data_file)

restaurantcollection.insert_many(data_json)


# #Step 2: Check inventory
# Manager can check the quantity of all the ingredients in the inventory 
# so that if any ingredient is not sufficient then it can be ordered

ingredients_collection = db.IngredientsRequired_collection
inventory_collection = db.Inventory_collection
quantitycheck_collection = db.QuantityCheck_collection

#Order along with its ingredients is saved in  ingredients_collection
ingredients_collection.insert_many( [
   { "Orderid": 10001, "Order": "Pizza", "Ingredientslist": [ "Cheese", "Tomatoes", "Onions" ] },
   { "Orderid": 10012, "Order": "Sandwich", "Ingredientslist": [ "Bread", "Butter","Cheese","Potatoes" ] }
])

#ingredients_collection is joined with inventory_collection
#and in return we get a new collection quantitycheck_collection with available quantity of ingredients 
data = list(ingredients_collection.aggregate([
   {
      "$lookup":
         {
            "from": "inventory_collection",
            "localField": "Ingredientslist",
            "foreignField": "Ingredient",
            "as": "quantity_info"
        }
   }
]))
quantitycheck_collection.insert_many(data)



#Step 3: Trigger that checks if data is inserted in restaurant data store with orderstatus as P
   #and staffallocated as N then insert cooking and serving staff from "staff data store"
   #into "restaurant data store" where staff isavailable=Y and then after allocation update isavailable = N

##Trigger Code - In MongoDB Atlas Triggers (Trigger name - realTimeStaffAllocation)


#4.1: Completed command from front end will update orderstatus in restaurant data store to C against the order id
restaurantcollection.update_one({ "order_id": "10001" },{'$set': {"orderstatus": "C"}});

#4.2: When orderstatus will get updated to C, trigger will be fired which will change staff availability in staff data store to Y
##Trigger Code - In MongoDB Atlas Triggers (Trigger name - ChangingStaffAvailability)

