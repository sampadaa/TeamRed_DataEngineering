from neo4j import GraphDatabase
import pymongo
from pymongo import MongoClient

#connect to mongoDB cluster
conn = "mongodb+srv://namita:mongodb@cluster0.tn7xj.mongodb.net/Hotel_database?retryWrites=true&w=majority"
client = MongoClient(conn)
db = client["Hotel_database"]

#find a staff from 'housekeeping' who is available
result = db.Staff_collection.find_one({
    "$and" : [{
                 "staff_dept_name" : "Housekeeping"
              },
              {
                   "staff_is_available" : "Y"
              }]
})
staff_name=result["staff_first_name"]
print(staff_name)

#connect to Neo4j desktop
uri = "neo4j://localhost:7687"
driver = GraphDatabase.driver(uri, auth=("neo4j", "pizza"))
hotel_id = input ("Enter hotel_id :")
print(hotel_id)
#hotel_id = '110120'
rooms=[]
route=[]

#get rooms which have 'toBeServiced:TRUE'
def get_rooms(tx, hotel_id):
    nodes = tx.run("MATCH (n:Location {toBeServiced: TRUE})-[r:IS_IN]->(m:Hotel {id: $hotel_id}) RETURN n.name AS room", hotel_id=hotel_id)
    for node in nodes:
        rooms.append(node["room"])
    print("rooms:", rooms)

#get the SHORTEST route between the rooms returned from above
def get_route(tx, name, name1):
    
    xyz=[]
    result = tx.run("MATCH (p1:Location { name: $name }),(p2:Location { name: $name1 }), path = shortestPath((p1)-[r:CONNECTED_TO*]-(p2)) RETURN path", name=name, name1=name1)
    for record in result:
        route=record["path"].nodes

    for i in range(len(route)) :
        xyz.append(route[i]["name"])
    print("route :",xyz)

def update_staff(tx, rooms, staff_name):
    nodedetails=[]
    np=[]
    x = tx.run("MATCH (n:Location {name: $rooms}) SET n.Staff_assigned = $staff_name, n.toBeServiced = FALSE RETURN n AS node", rooms=rooms,staff_name=staff_name)
    print(x)
    for node in x:
        nodedetails.append(node["node"])
    print(nodedetails)
    
    for i in range(len(nodedetails)) :
        np.append(nodedetails[i]["toBeServiced"])
    print("room status of toBeServiced after update :",np)

with driver.session() as session:
    session.read_transaction(get_rooms, hotel_id)
    session.read_transaction(get_route, rooms[len(rooms)-1], rooms[0])
    for j in range(len(rooms)):
        session.write_transaction(update_staff, rooms[j], staff_name)

driver.close()

#update staff's status to not available
result1 = db.Staff_collection.update_one(
   { "staff_first_name":  staff_name},
     {
     "$set": { "staff_is_available": "N" }
     }
)